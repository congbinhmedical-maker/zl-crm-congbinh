<template>
  <aside class="info-panel">
    <!-- ════════ HEADER: Phase 8.C Score Banner (3 stat cards + avatar below) ════════ -->
    <header class="ip-header">
      <button class="ip-close" title="Đóng" @click="$emit('close')">×</button>
      <ScoreBanner :scores="scoreData">
        <template #avatar>
          <Avatar
            :src="props.contact?.avatarUrl"
            :name="headerFullName"
            :size="56"
            :gradient-seed="props.contact?.id || headerFullName"
            class="ip-avatar-big"
          />
        </template>
        <template #name>
          <div class="ip-name-line" :title="headerFullName">{{ headerFullName }}</div>
          <div v-if="props.contact?.zaloUid" class="ip-id">UID: {{ props.contact.zaloUid }}</div>
          <div class="ip-care-row-inline">
            <CareStatusBadge
              :model-value="(form.status as string | null) || 'new'"
              @update:model-value="onChangeCareStatus"
            />
          </div>
        </template>
      </ScoreBanner>
    </header>

    <!-- ════════ Tab bar ════════ -->
    <nav class="ip-tabs">
      <button
        class="ip-tab"
        :class="{ active: activeTab === 'profile' }"
        @click="activeTab = 'profile'"
      >
        <span class="ic">👤</span> Hồ sơ
      </button>
      <button
        class="ip-tab"
        :class="{ active: activeTab === 'relations' }"
        @click="activeTab = 'relations'"
      >
        <span class="ic">🔗</span> Quan hệ
        <span v-if="relationBadgeCount" class="tab-badge">{{ relationBadgeCount }}</span>
      </button>
      <button
        class="ip-tab"
        :class="{ active: activeTab === 'activity', 'badge-bump': badgeBump }"
        data-fly-target="activity-tab"
        @click="activeTab = 'activity'"
      >
        <span class="ic">📅</span> Lịch hẹn
        <span v-if="activityBadgeCount || pendingAptBump" class="tab-badge">{{ (activityBadgeCount ?? 0) + pendingAptBump }}</span>
      </button>
      <button
        v-if="props.friendId"
        class="ip-tab"
        :class="{ active: activeTab === 'score' }"
        :title="`Điểm KH: ${props.contact?.leadScore ?? 0}`"
        @click="activeTab = 'score'"
      >
        <span class="ic">⭐</span> Điểm
        <span v-if="(props.contact?.leadScore ?? 0) > 0" class="tab-badge tab-badge-score">
          {{ props.contact?.leadScore }}
        </span>
      </button>
    </nav>

    <!-- ════════ Tab content (scroll) ════════ -->
    <div class="ip-tab-content">

      <!-- ══════ TAB 1: HỒ SƠ ══════ -->
      <div v-show="activeTab === 'profile'" class="tab-pane">
        <!-- Inline form: collapsed (Tên Zalo + SĐT) hoặc expanded (full 9 rows). Auto-collapse sau 5s. -->
        <section class="ip-form" :class="{ collapsed: !infoExpanded }">
          <!-- Always visible: Tên Zalo -->
          <div class="ip-form-row">
            <span class="ip-icon">👤</span>
            <span class="ip-label">Tên Zalo</span>
            <input v-model="form.fullName" placeholder="Tên Zalo cung cấp" @blur="saveContact" />
          </div>

          <!-- Always visible: SĐT chính -->
          <div class="ip-form-row">
            <span class="ip-icon">📞</span>
            <span class="ip-label">SĐT</span>
            <div class="phone-cell">
              <input v-model="form.phone" placeholder="SĐT chính" @blur="saveContact" />
              <button
                v-if="form.phone && infoExpanded"
                class="show-extra-phones"
                :title="showExtraPhones ? 'Ẩn SĐT phụ' : 'Hiện SĐT phụ'"
                @click="showExtraPhones = !showExtraPhones"
              >
                {{ showExtraPhones ? '−' : '+' }} {{ filledExtras }}/2
              </button>
            </div>
          </div>

          <!--
            Toggle 1 nút, 3-state cycle:
              hidden → click → auto (countdown 5s)
              auto → click → sticky (ghim 📌, cancel countdown)
              sticky → click → hidden
          -->
          <button class="info-expand-toggle" :class="{ 'is-sticky': isSticky }" @click="toggleInfoExpand">
            <span v-if="!infoExpanded">▾ Xem đầy đủ</span>
            <span v-else-if="isSticky">▴ Thu gọn <span class="sticky-badge" title="Đã ghim — không tự thu">📌</span></span>
            <span v-else>📌 Ghim mở (tự thu sau {{ collapseRemain }}s)</span>
          </button>

          <!-- Expanded fields -->
          <template v-if="infoExpanded">
            <div class="ip-form-row">
              <span class="ip-icon">✏</span>
              <span class="ip-label" title="Tên gợi nhớ Zalo per-pair — sync 2-way với Zalo Real">Tên gợi nhớ</span>
              <input
                :value="aliasDraft"
                placeholder="Sync với Zalo Real"
                @input="aliasDraft = ($event.target as HTMLInputElement).value"
                @blur="saveAlias"
                @keydown.enter.prevent="saveAlias"
              />
            </div>
            <div class="ip-form-row">
              <span class="ip-icon">📅</span>
              <span class="ip-label">Ngày sinh</span>
              <input type="date" v-model="form.birthDate" @blur="saveContact" />
            </div>
            <div class="ip-form-row">
              <span class="ip-icon">⚧</span>
              <span class="ip-label">Giới tính</span>
              <select v-model="form.gender" @change="saveContact">
                <option :value="null">Không rõ</option>
                <option value="female">Nữ</option>
                <option value="male">Nam</option>
                <option value="other">Khác</option>
              </select>
            </div>
            <template v-if="showExtraPhones">
              <div class="ip-form-row sub">
                <span class="ip-label">SĐT 2</span>
                <input v-model="form.phone2" placeholder="SĐT phụ 1" @blur="saveContact" />
              </div>
              <div class="ip-form-row sub">
                <span class="ip-label">SĐT 3</span>
                <input v-model="form.phone3" placeholder="SĐT phụ 2" @blur="saveContact" />
              </div>
            </template>
            <!-- 3 field Email · Địa chỉ · Nghề: ẨN khỏi cột 4 (quick view chat panel).
                 Schema giữ nguyên — data vẫn lưu/edit qua tab "Hồ sơ KH tổng hợp" (phase sau).
                 Xem ContactProfileView.vue stub + use-contact-profile.ts composable. -->
            <button
              v-if="contact?.id"
              class="info-fullprofile-link"
              type="button"
              :title="'Xem hồ sơ KH tổng hợp (email, địa chỉ, nghề, ...)'"
              @click="openFullProfile"
            >
              <span>✨ Xem hồ sơ KH tổng hợp →</span>
            </button>
          </template>
        </section>

        <v-alert v-if="saveSuccess" type="success" density="compact" class="mx-3 my-2" closable
          @click:close="saveSuccess = false">
          Đã lưu thành công!
        </v-alert>
        <v-alert v-if="saveError" type="error" density="compact" class="mx-3 my-2" closable
          @click:close="saveError = false">
          Lưu thất bại, thử lại.
        </v-alert>

        <!-- Tag CRM section moved to MessageThread chat input bar (Smax-style) -->

        <!-- ──── Customer Timeline (Notes + Activity unified) ──── -->
        <section class="ip-section ip-notes-section">
          <CustomerTimelineSection
            :contact-id="props.contactId"
            :contact-name="headerFullName"
            @appointment-created="onAppointmentCreated"
          />
        </section>

        <!-- Phase 8 — Engagement Heatmap Timeline -->
        <section v-if="props.contactId" class="ip-section">
          <EngagementHeatmap :contact-id="props.contactId" />
        </section>
      </div>

      <!-- ══════ TAB 2: QUAN HỆ (per-nick) ══════ -->
      <div v-show="activeTab === 'relations'" class="tab-pane">
        <!-- Nick CRM chăm (= KH Con per nick) — real data từ /contacts/:id -->
        <section v-if="relations.friends.length" class="ip-section">
          <div class="ip-section-title">
            <span class="accent" style="background: var(--smax-info)" />
            💬 Nick CRM đang chăm ({{ relations.friends.length }})
            <span class="scope-tag global">per-nick</span>
          </div>
          <div class="friends-list">
            <div v-for="f in relations.friends" :key="f.id" class="friend-card">
              <div class="friend-card-head">
                <Avatar :src="f.zaloAccount.avatarUrl" :name="f.zaloAccount.displayName || 'Nick'" :size="32" :gradient-seed="f.id" platform="zalo" />
                <div class="friend-card-title">
                  <div class="friend-name">{{ f.zaloAccount.displayName || 'Nick' }}</div>
                  <div class="friend-sub">
                    <span v-if="f.zaloAccount.owner" class="sale-name">Sale: {{ f.zaloAccount.owner.fullName }}</span>
                  </div>
                </div>
                <span :class="['status-pill', friendKindClass(f.relationshipKind)]" :title="'Trạng thái kết bạn Zalo'">
                  {{ friendKindLabel(f.relationshipKind) }}
                </span>
                <span
                  v-if="f.hasConversation"
                  class="conv-badge conv-badge--on"
                  title="Đã từng nhắn 1-1 với KH qua nick này"
                >💬</span>
                <span
                  v-else
                  class="conv-badge conv-badge--off"
                  title="Chỉ kết bạn Zalo, chưa có hội thoại 1-1 nào"
                >ø</span>
              </div>
              <!-- KH theo nick này: avatar + tên Zalo riêng cho identity này (KHÔNG dùng tên KH Cha) -->
              <div class="friend-customer-row">
                <Avatar
                  :src="f.zaloAvatarUrl"
                  :name="f.zaloDisplayName || `KH-${f.zaloUidInNick.slice(-4)}`"
                  :size="28"
                  :gradient-seed="f.zaloUidInNick"
                />
                <div class="friend-customer-info">
                  <div class="friend-customer-name">{{ f.zaloDisplayName || `KH-${f.zaloUidInNick.slice(-4)}` }}</div>
                  <code class="uid">UID: {{ f.zaloUidInNick }}</code>
                </div>
              </div>
              <div class="friend-card-row">
                <span class="lbl">Trạng thái KH:</span>
                <span
                  v-if="f.statusRef"
                  class="chip status-edit"
                  :style="{ background: chipBg(f.statusRef.color), color: chipFg(f.statusRef.color) }"
                >{{ f.statusRef.name }}</span>
                <span v-else class="empty">— đặt —</span>
                <span class="lbl ml-auto">Score:</span>
                <strong>{{ f.leadScore ?? 0 }}</strong>
              </div>
              <div class="friend-card-row meta-line">
                <span>📥 <strong>{{ f.totalInbound }}</strong></span>
                <span>📤 <strong>{{ f.totalOutbound }}</strong></span>
                <span v-if="f.becameFriendAt">KB: {{ relativeTime(f.becameFriendAt) }}</span>
                <span v-if="f.lastInboundAt">Last: {{ relativeTime(f.lastInboundAt) }}</span>
              </div>
              <div class="friend-card-actions">
                <button class="btn-sm-danger" :title="'Tách Con này thành KH Cha mới'" @click="onPromoteFriend(f)">
                  ✂ Tách thành KH Cha riêng
                </button>
              </div>
            </div>
          </div>
        </section>

        <!-- Empty state -->
        <div v-if="!relations.friends.length" class="tab-empty">
          <p>KH này chưa có nick CRM nào chăm.</p>
        </div>

        <!-- Label Zalo native (per-nick) -->
        <section class="ip-section">
          <div class="ip-section-title">
            <span class="accent" style="background: var(--smax-warning)" />
            🔖 Label Zalo (native)
            <span class="scope-tag pernick">per-nick</span>
          </div>
          <TagChipList
            :model-value="zaloLabels"
            chip-class="chip-zalo"
            add-label="Sync từ Zalo"
            :readonly="true"
          />
          <div v-if="!zaloLabels.length" class="empty-section">
            Chưa có label nào — sync từ Zalo SDK
          </div>
        </section>

        <!-- Tag riêng nick × KH (per-pair) -->
        <section class="ip-section">
          <div class="ip-section-title">
            <span class="accent" style="background: var(--smax-warning)" />
            🏷 Tag riêng nick × KH
            <span class="scope-tag pernick">per-nick</span>
          </div>
          <TagChipList
            v-model="perPairTags"
            chip-class="chip-info"
            add-label="Thêm"
            @update:model-value="onPerPairTagsChange"
          />
        </section>

      </div>

      <!-- ══════ TAB 3: HOẠT ĐỘNG (AI + Automation + Lịch hẹn) ══════ -->
      <div v-show="activeTab === 'activity'" class="tab-pane">
        <!-- AI Summary -->
        <section v-if="aiSummary || aiSummaryLoading" class="ip-section">
          <div class="ip-section-title">
            <span class="accent" style="background: #9c27b0" />
            ✨ AI Tóm tắt
            <button class="refresh-mini" :disabled="aiSummaryLoading" @click="$emit('refresh-ai-summary')">↻</button>
          </div>
          <AiSummaryCard :summary="aiSummary" :loading="aiSummaryLoading" />
        </section>

        <!-- AI Sentiment -->
        <section v-if="aiSentiment || aiSentimentLoading" class="ip-section">
          <div class="ip-section-title">
            <span class="accent" style="background: #ec407a" />
            💗 Cảm xúc khách hàng
            <button class="refresh-mini" :disabled="aiSentimentLoading" @click="$emit('refresh-ai-sentiment')">↻</button>
          </div>
          <AiSentimentBadge :sentiment="aiSentiment" />
          <div v-if="aiSentiment?.reason" class="sentiment-reason">{{ aiSentiment.reason }}</div>
        </section>

        <!-- Automation cards (per-nick — backend chưa có schema, ẩn nếu rỗng) -->
        <AutomationCardList :cards="automationCards" @action="onAutomationAction" @attach="onAttachAutomation" />

        <!-- Lịch hẹn -->
        <ChatAppointments
          v-if="props.contactId"
          :contact-id="props.contactId"
          :contact-name="headerFullName"
          :appointments="contactAppointments"
          @refresh="reloadAppointments"
        />

        <!-- Empty state khi không có gì trong tab -->
        <div v-if="!hasAnyActivity" class="tab-empty">
          <p>Chưa có hoạt động — sau khi có conv tin nhắn, AI sẽ tự tóm tắt + phân tích cảm xúc.</p>
        </div>
      </div>

      <!-- ══════ TAB 4: ĐIỂM (Lead Scoring) ══════ -->
      <div v-show="activeTab === 'score'" class="tab-pane tab-pane-score">
        <ScoreInlinePanel
          v-if="props.friendId"
          :friend-id="props.friendId"
          :stage-label="scoreStageLabel"
          @view-history="openScoreHistory"
        />
        <div v-else class="tab-empty">
          <p>Tab Điểm chỉ áp dụng cho hội thoại 1-1 (có Friend).</p>
        </div>
      </div>
    </div>

    <!-- Score history modal (overlay full screen, Teleport to body) -->
    <ScoreHistoryModal
      v-model="scoreHistoryOpen"
      :friend-id="props.friendId ?? null"
      :contact-name="headerFullName"
    />
  </aside>
</template>

<script setup lang="ts">
import { ref, computed, watch, onBeforeUnmount, onMounted } from 'vue';
import { useRouter } from 'vue-router';
import type { Contact } from '@/composables/use-contacts';
import type { AiSentiment } from '@/composables/use-chat';
import { useChatContactPanel } from '@/composables/use-chat-contact-panel';
import ChatAppointments from './ChatAppointments.vue';
import AiSummaryCard from '@/components/ai/ai-summary-card.vue';
import AiSentimentBadge from '@/components/ai/ai-sentiment-badge.vue';
import AutomationCardList, { type AutomationCard } from './AutomationCardList.vue';
import TagChipList from '@/components/ui/TagChipList.vue';
import Avatar from '@/components/ui/Avatar.vue';
import CareStatusBadge from '@/components/ui/CareStatusBadge.vue';
import type { CareStatusValue } from '@/constants/care-status';
import { useToast } from '@/composables/use-toast';
import { api } from '@/api';
import CustomerTimelineSection from './CustomerTimelineSection.vue';
import EngagementHeatmap from './EngagementHeatmap.vue';
import ScoreBanner from './ScoreBanner.vue';
import ScoreInlinePanel from '@/components/scoring/ScoreInlinePanel.vue';
import ScoreHistoryModal from '@/components/scoring/ScoreHistoryModal.vue';

const props = defineProps<{
  contactId: string | null;
  contact: Contact | null;
  // Nick CRM đang xem KH này — dùng để xác định Friend row "active" cho per-pair tag.
  activeZaloAccountId?: string | null;
  // Friend.id của cặp (contact × activeZaloAccount). Cần để fetch score breakdown per-pair.
  friendId?: string | null;
  // Friendship per-pair (nick × KH) — chứa aliasInNick để sync 2-way với Zalo Real.
  friendship?: { id?: string; aliasInNick?: string | null } | null;
  aiSummary: string;
  aiSummaryLoading: boolean;
  aiSentiment: AiSentiment | null;
  aiSentimentLoading: boolean;
}>();

const emit = defineEmits<{
  close: [];
  saved: [];
  'refresh-ai-summary': [];
  'refresh-ai-sentiment': [];
}>();

const {
  form, saveSuccess, saveError,
  contactAppointments,
  saveContact, reloadAppointments,
} = useChatContactPanel(
  () => props.contactId,
  () => props.contact,
  () => emit('saved'),
);

// ════════ Tên gợi nhớ Zalo (per-pair, sync 2-way với Zalo Real) ════════
// Bound to Friend.aliasInNick — PATCH /friends/:id sẽ:
//   1. Update DB
//   2. Fire-and-forget call api.changeFriendAlias / removeFriendAlias → push Zalo Real
const aliasDraft = ref('');
watch(() => props.friendship?.aliasInNick, (v) => {
  aliasDraft.value = v || '';
}, { immediate: true });

const aliasToast = useToast();
async function saveAlias() {
  const friendId = props.friendship?.id;
  if (!friendId) return;
  const trimmed = aliasDraft.value.trim();
  const newAlias = trimmed.length ? trimmed : null;
  if (newAlias === (props.friendship?.aliasInNick || null)) return;  // no-op
  try {
    await api.patch(`/friends/${friendId}`, { aliasInNick: newAlias });
    aliasToast.success(newAlias ? `Đã đổi tên gợi nhớ → "${newAlias}"` : 'Đã xoá tên gợi nhớ');
    emit('saved');  // parent refetch để lấy alias mới + reflect lên cột 2 + header
  } catch (err) {
    aliasToast.error('Lưu tên gợi nhớ thất bại');
  }
}

// ════════ Tab state (persist sang tab khác KH khác) ════════
const activeTab = ref<'profile' | 'relations' | 'activity' | 'score'>('profile');

// ════════════════════════════════════════════════════════════════════════
// Info section state machine — 3 modes, in-memory only (KHÔNG persist):
//   'auto'   → expand + countdown 5s → auto-hide
//   'sticky' → user click 2nd time để ghim → KHÔNG auto-hide
//   'hidden' → ẩn (mặc định, hoặc sau countdown, hoặc user thu gọn)
//
// Flow toggle button (1 nút, 3-state cycle):
//   hidden → click → 'auto' (5s countdown)
//   'auto' (đang countdown) → click → 'sticky' (cancel countdown, ghim 📌)
//   'sticky' → click → 'hidden'
//
// Reload page / switch conv / switch tab → RESET về hidden (KHÔNG persist).
// Sticky chỉ giữ trong cùng conv + cùng tab Hồ Sơ.
// ════════════════════════════════════════════════════════════════════════
type ExpandMode = 'auto' | 'sticky' | 'hidden';
const expandMode = ref<ExpandMode>('hidden');
const infoExpanded = computed(() => expandMode.value !== 'hidden');
const isSticky = computed(() => expandMode.value === 'sticky');
const collapseRemain = ref(5);
let collapseTimer: ReturnType<typeof setInterval> | null = null;

function clearCollapseTimer() {
  if (collapseTimer) { clearInterval(collapseTimer); collapseTimer = null; }
}
function startAutoCollapse() {
  clearCollapseTimer();
  collapseRemain.value = 5;
  collapseTimer = setInterval(() => {
    collapseRemain.value--;
    if (collapseRemain.value <= 0) {
      // Chỉ tự hide khi đang ở mode 'auto'. Sticky thì never timeout.
      if (expandMode.value === 'auto') expandMode.value = 'hidden';
      clearCollapseTimer();
    }
  }, 1000);
}

// 3-state cycle trên 1 nút toggle (theo user spec):
//   hidden → 'auto' (countdown 5s)
//   'auto' → 'sticky' (ghim, cancel countdown)
//   'sticky' → 'hidden'
function toggleInfoExpand() {
  if (expandMode.value === 'hidden') {
    // Open lần đầu → auto countdown 5s
    expandMode.value = 'auto';
    startAutoCollapse();
  } else if (expandMode.value === 'auto') {
    // Click lần nữa khi đang auto → ghim sticky (cancel countdown)
    expandMode.value = 'sticky';
    clearCollapseTimer();
  } else {
    // sticky → hidden
    expandMode.value = 'hidden';
    clearCollapseTimer();
  }
}

// Khi click tab Hồ Sơ: auto-expand + countdown (KHÔNG sticky default).
// Khi switch tab khác: hidden.
watch(activeTab, (tab) => {
  if (tab === 'profile') {
    expandMode.value = 'auto';
    startAutoCollapse();
  } else {
    clearCollapseTimer();
    expandMode.value = 'hidden';
  }
});

// Animation: khi NotesSection emit 'appointment-created' (fly anim đã xong) → +1 badge với bump effect.
// pendingAptBump giữ count cho tới khi reloadAppointments() refresh data thực từ backend.
const pendingAptBump = ref(0);
const badgeBump = ref(false);
function onAppointmentCreated() {
  pendingAptBump.value++;
  badgeBump.value = true;
  setTimeout(() => { badgeBump.value = false; }, 600);
  // Reset bump NGAY trong .then() (không setTimeout 300ms) để Vue batch cùng frame
  //   activityBadgeCount: 0 → 1  (do reload)
  //   pendingAptBump:     1 → 0  (do reset)
  // Cả 2 update cùng microtask → 1 re-render duy nhất, badge từ 1 (bump) → 1 (real),
  // không flash số 2. Bug cũ: setTimeout 300ms giữ bump=1 sau khi data đã = 1 → badge = 2.
  reloadAppointments().then(() => {
    pendingAptBump.value = 0;
  });
}

// Listen global 'appointment-created' event — fire khi MessageThread (cột 3) tạo
// nhắc hẹn qua icon 📅 trong toolbar. Cùng pattern với zalo-labels-synced.
function onGlobalAppointmentCreated() { onAppointmentCreated(); }
onMounted(() => window.addEventListener('appointment-created', onGlobalAppointmentCreated));
onBeforeUnmount(() => {
  clearCollapseTimer();
  window.removeEventListener('appointment-created', onGlobalAppointmentCreated);
});

// ════════ Score history modal (mở từ tab Điểm "Xem toàn bộ →") ════════
const scoreHistoryOpen = ref(false);
function openScoreHistory() {
  scoreHistoryOpen.value = true;
}

// Stage label hiển thị cạnh điểm tổng (vd "warm-lead" lấy từ friendship.statusRef.name)
const scoreStageLabel = computed<string | null>(() => {
  const c = props.contact as Contact & { friendship?: { statusRef?: { name?: string } | null } } | null;
  return c?.friendship?.statusRef?.name || null;
});

// ════════ Relations data (friends per nick = KH Con) — fetch khi đổi contact ═══
interface FriendItem {
  id: string;
  zaloUidInNick: string;
  relationshipKind: string;
  hasConversation: boolean;
  totalInbound: number;
  totalOutbound: number;
  becameFriendAt: string | null;
  lastInboundAt: string | null;
  leadScore: number;
  zaloDisplayName: string | null;
  zaloAvatarUrl: string | null;
  crmTagsPerNick: string[];
  statusRef: { id: string; name: string; order: number; color: string | null } | null;
  zaloAccount: { id: string; displayName: string | null; avatarUrl?: string | null; owner: { id: string; fullName: string } | null };
}
interface RelationsState {
  friends: FriendItem[];
}
const relations = ref<RelationsState>({ friends: [] });

async function fetchRelations(contactId: string) {
  try {
    const res = await api.get<{ friends?: FriendItem[] }>(`/contacts/${contactId}`);
    // Sort: "đang chat" lên đầu — sale chỉ care nick đã thực sự nhắn 1-1.
    const all = res.data.friends || [];
    all.sort((a, b) => {
      if (a.hasConversation !== b.hasConversation) return a.hasConversation ? -1 : 1;
      const at = a.lastInboundAt || '';
      const bt = b.lastInboundAt || '';
      return bt.localeCompare(at);
    });
    relations.value = { friends: all };
  } catch (err) {
    console.error('[ChatContactPanel] fetchRelations error:', err);
    relations.value = { friends: [] };
  }
}

function chipBg(hex: string | null | undefined): string {
  if (!hex) return 'rgba(90,100,120,0.10)';
  const m = hex.match(/^#([0-9a-f]{6})$/i);
  if (!m) return 'rgba(90,100,120,0.10)';
  const n = parseInt(m[1], 16);
  return `rgba(${(n>>16)&255},${(n>>8)&255},${n&255},0.15)`;
}
function chipFg(hex: string | null | undefined): string { return hex || 'var(--smax-grey-700)'; }

async function onPromoteFriend(f: FriendItem) {
  const name = prompt(`Tên cho KH Cha mới (Nick "${f.zaloAccount.displayName}" × UID ${f.zaloUidInNick}):`, '');
  if (name === null) return;  // cancelled
  try {
    const res = await api.post<{ newContact: { id: string; fullName: string }; movedConversations: number }>(
      `/friends/${f.id}/promote-to-parent`,
      { fullName: name.trim() || undefined },
    );
    toast.success(`Đã tạo KH Cha mới: ${res.data.newContact.fullName}. ${res.data.movedConversations} conversation đã chuyển.`);
    if (props.contactId) await fetchRelations(props.contactId);
    emit('saved');
  } catch (err) {
    const msg = (err as { response?: { data?: { error?: string } } }).response?.data?.error || 'Tách thất bại';
    toast.error(msg);
  }
}

function friendKindLabel(k: string): string {
  if (k === 'friend') return '✓ Đã KB';
  if (k === 'pending_friend') return '… Pending';
  if (k === 'chatting_stranger') return '👥 Lạ';
  if (k === 'ghost') return '🚫 Ngắt';
  return k;
}
function friendKindClass(k: string): string {
  if (k === 'friend') return 'pill-success';
  if (k === 'pending_friend') return 'pill-warning';
  if (k === 'chatting_stranger') return 'pill-info';
  return 'pill-grey';
}

// ════════ Care status (dropdown qua CareStatusBadge — emit value mới) ════════
function onChangeCareStatus(value: CareStatusValue) {
  form.status = value;
  saveContact();
}

// ════════ Header name (Avatar component handle initials + gender + gradient) ════════
// B7 fix — Contact stub có thể fullName='Unknown'; fallback qua aliasInNick (props.friendship)
// rồi activeFriend.zaloDisplayName (nick đang chăm) trước khi hiện 'Khách hàng'.
const headerFullName = computed(() => {
  const isUsable = (s: string | null | undefined): s is string =>
    !!s && s.trim().length > 0 && s.trim().toLowerCase() !== 'unknown';
  if (isUsable(props.contact?.crmName)) return props.contact!.crmName!;
  if (isUsable(props.contact?.fullName)) return props.contact!.fullName!;
  if (isUsable(props.friendship?.aliasInNick)) return props.friendship!.aliasInNick!;
  const af = activeFriend.value as { zaloDisplayName?: string | null } | null;
  if (isUsable(af?.zaloDisplayName)) return af!.zaloDisplayName!;
  return 'Khách hàng';
});

// Lead score tier để màu badge overlay trên avatar (thấp/TB/cao)
// ════════ Phase 8.C — ScoreBanner 3 score data ════════
const scoreData = computed(() => ({
  lead: props.contact?.leadScore ?? null,
  engagement: props.contact?.engagementScore ?? null,
  priority: props.contact?.priorityScore ?? null,
  engagementTrend: props.contact?.engagementTrend ?? null,
  engagementPattern: props.contact?.engagementPattern ?? null,
}));

// ════════ Phones extras ════════
const showExtraPhones = ref(false);
const filledExtras = computed(() => [form.phone2, form.phone3].filter(Boolean).length);

// Tag CRM hệ thống đã chuyển sang TagCrmBar trên chat input (Cột 3).
// Zalo Real labels chuyển sang dropdown trong header Cột 3 (MessageThread).

// ════════ Automation cards (placeholder — chờ backend) ════════
const automationCards = computed<AutomationCard[]>(() => {
  // Khi backend bổ sung endpoint /contacts/:id/automations sẽ map vào đây.
  return [];
});
function onAutomationAction(_id: string, _kind: string) { /* TODO wire to API */ }
function onAttachAutomation() { toast.warning('Gắn automation: chờ backend schema delta'); }

// ════════ Hồ sơ KH tổng hợp (phase sau) ════════
// Tạm thời chỉ navigate sang route /contacts/:id/profile (skeleton view).
// Sau khi backend GET /api/v1/contacts/:id/profile sẵn sàng + ContactProfileView
// implement đầy đủ → tab này hiển thị 3 field Email/Address/Occupation đã ẩn ở cột 4.
function openFullProfile() {
  if (!props.contact?.id) return;
  router.push(`/contacts/${props.contact.id}/profile`);
}

// MOCK: zaloLabels (per-pair native labels) chưa expose qua API
const zaloLabels = ref<string[]>([]);

// Per-pair CRM tags: tags RIÊNG cho cặp (nick active × KH). KHÁC contact.tags
// (cấp KH chung). Trigger PATCH /friends/:id để persist.
const activeFriend = computed<FriendItem | null>(() => {
  if (!props.activeZaloAccountId) return null;
  return relations.value.friends.find(f => f.zaloAccount.id === props.activeZaloAccountId) || null;
});
const perPairTags = computed<string[]>({
  get: () => activeFriend.value?.crmTagsPerNick || [],
  set: (v) => {
    if (activeFriend.value) activeFriend.value.crmTagsPerNick = v;
  },
});
async function onPerPairTagsChange(tags: string[]) {
  if (!activeFriend.value) {
    toast.warning('Chưa xác định nick CRM nào đang chăm KH này');
    return;
  }
  try {
    await api.patch(`/friends/${activeFriend.value.id}`, { crmTagsPerNick: tags });
  } catch (err) {
    console.error('[ChatContactPanel] save per-pair tags failed:', err);
    toast.error('Lưu tag thất bại');
  }
}

// MOCK: 3 nick khác cũng chăm — chờ /contacts/:id/friendships
interface OtherNick { id: string; short: string; name: string; pillClass: string; pillLabel: string }
const otherNicks = computed<OtherNick[]>(() => [] as OtherNick[]);

// ════════ Tab badges ════════
const relationBadgeCount = computed(() => otherNicks.value.length || 0);
const activityBadgeCount = computed(() => {
  let n = 0;
  if (automationCards.value.length) n += automationCards.value.length;
  if (contactAppointments.value.length) n += contactAppointments.value.length;
  return n || null;
});

const hasAnyActivity = computed(() =>
  !!(props.aiSummary || props.aiSentiment || automationCards.value.length || contactAppointments.value.length),
);

const toast = useToast();
const router = useRouter();

// Khi đổi sang contact mới, reset về tab Hồ sơ + refetch relations
// (NotesSection tự fetch khi prop contactId đổi).
// Cũng force reset infoExpanded + start countdown — nếu activeTab đã = 'profile',
// watch(activeTab) sẽ KHÔNG fire khi cùng giá trị → form section stuck ở state cũ.
watch(() => props.contactId, (id) => {
  activeTab.value = 'profile';
  // Switch conv hoặc reload page → reset về 'auto' (countdown 5s).
  // KHÔNG persist sticky giữa các conv (theo spec: sticky chỉ trong cùng conv).
  expandMode.value = 'auto';
  startAutoCollapse();
  if (id) void fetchRelations(id);
  else relations.value = { friends: [] };
}, { immediate: true });

function relativeTime(dateStr: string) {
  const diff = Date.now() - new Date(dateStr).getTime();
  const days = Math.floor(diff / (1000 * 60 * 60 * 24));
  if (days === 0) return 'hôm nay';
  if (days === 1) return 'hôm qua';
  return `${days} ngày trước`;
}
</script>

<style scoped>
.info-panel {
  background: var(--smax-bg);
  border-left: 1px solid var(--smax-grey-200);
  display: flex; flex-direction: column;
  height: 100%; overflow: hidden;
  flex-shrink: 0;
}

/* ════════ Header (pinned) ════════ */
.ip-header {
  padding: 0;
  text-align: left;
  border-bottom: 1px solid var(--smax-grey-200);
  position: relative;
  flex-shrink: 0;
}
/* Avatar + name layout inside ScoreBanner slot */
.ip-header .ip-name-line {
  font-size: 15px;
  font-weight: 700;
  line-height: 1.2;
  margin-top: 0;
  padding: 0;
  text-align: left;
}
.ip-header .ip-id {
  font-size: 10.5px;
  margin-top: 2px;
  padding: 0;
  text-align: left;
}
.ip-care-row-inline {
  margin-top: 5px;
  display: flex;
}
/* Tab 4 "Điểm" — score panel content full-width 280px, vertical stack */
.tab-pane-score {
  padding: 12px 14px 18px;
}
/* Tab badge cho score (khác badge số tin chưa đọc) */
.tab-badge-score {
  background: #fef3c7 !important;
  color: #b45309 !important;
  font-weight: 700 !important;
  min-width: 24px;
}

.ip-close {
  position: absolute; top: 7px; right: 9px;
  width: 26px; height: 26px;
  background: transparent; border: none;
  font-size: 20px; cursor: pointer;
  color: var(--smax-grey-700);
  border-radius: 50%;
  z-index: 5;
}
.ip-close:hover { background: var(--smax-grey-100); }


.ip-avatar-wrap {
  position: relative;
  display: inline-block;
}
.ip-avatar-big {
  display: block;
  margin: 0 auto;
}

/* Lead score badge — overlay trên avatar (góc dưới-phải), Smax-style "điểm KH" */
.lead-score-badge {
  position: absolute;
  bottom: -3px;
  right: -8px;
  background: var(--smax-bg, #fff);
  border: 2px solid #fff;
  border-radius: 11px;
  padding: 1px 7px 1px 6px;
  font-size: 11px;
  font-weight: 700;
  line-height: 1.4;
  white-space: nowrap;
  box-shadow: 0 1px 4px rgba(0,0,0,0.12);
  cursor: help;
}
.lead-score-badge.tier-hot   { background: #ffebee; color: #c62828; border-color: #ffcdd2; }
.lead-score-badge.tier-warm  { background: #fff3e0; color: #ef6c00; border-color: #ffe0b2; }
.lead-score-badge.tier-cool  { background: #e3f2fd; color: #1565c0; border-color: #bbdefb; }
.lead-score-badge.tier-cold  { background: #f5f6fa; color: var(--smax-grey-600); border-color: #e0e0e0; }

.ip-name-line {
  margin-top: 7px;
  font-size: 14px; font-weight: 600;
  color: var(--smax-text);
  overflow: hidden; text-overflow: ellipsis; white-space: nowrap;
  padding: 0 17px;
}
.ip-id {
  font-size: 10.5px;
  color: var(--smax-grey-700);
  margin-top: 3px;
  font-family: ui-monospace, "Cascadia Code", Menlo, monospace;
  word-break: break-all;
  padding: 0 17px;
}
.ip-care-row { margin-top: 7px; }
.care-status-select {
  background: rgba(255,145,0,0.15);
  color: #ef6c00;
  border: 1px solid rgba(255,145,0,0.3);
  padding: 4px 11px;
  border-radius: 13px;
  font-size: 11.5px; font-weight: 500;
  cursor: pointer;
  font-family: inherit;
}
.care-status-select:hover { background: rgba(255,145,0,0.22); }

/* ════════ Tab bar ════════ */
.ip-tabs {
  display: flex;
  border-bottom: 1px solid var(--smax-grey-200);
  background: var(--smax-grey-50);
  flex-shrink: 0;
}
.ip-tab {
  flex: 1;
  background: transparent; border: none;
  padding: 9px 7px;
  cursor: pointer;
  font-size: 12.5px; font-weight: 500;
  color: var(--smax-grey-700);
  border-bottom: 2px solid transparent;
  margin-bottom: -1px;
  display: inline-flex; align-items: center; justify-content: center; gap: 4px;
  font-family: inherit;
  position: relative;
  transition: color 0.15s;
}
.ip-tab .ic { font-size: 13px; line-height: 1; }
.ip-tab:hover { color: var(--smax-primary); background: var(--smax-grey-100); }
.ip-tab.active {
  color: var(--smax-primary);
  border-bottom-color: var(--smax-primary);
  background: var(--smax-bg);
  font-weight: 600;
}
.tab-badge {
  position: absolute;
  top: 5px; right: 9px;
  background: var(--smax-primary);
  color: white;
  font-size: 10px; font-weight: 700;
  padding: 0 5px;
  border-radius: 8px;
  min-width: 16px;
  line-height: 14px;
  text-align: center;
  transition: transform 0.18s ease;
}
/* Bump effect — khi NotesSection báo created → scale + glow để feedback +1 */
.ip-tab.badge-bump .tab-badge {
  animation: badgeBump 0.6s ease;
}
@keyframes badgeBump {
  0%   { transform: scale(1); background: var(--smax-primary); }
  30%  { transform: scale(1.5); background: #f57c00; box-shadow: 0 0 0 6px rgba(245, 124, 0, 0.25); }
  60%  { transform: scale(1.1); background: #f57c00; }
  100% { transform: scale(1); background: var(--smax-primary); box-shadow: none; }
}

/* ════════ Tab content (scroll) ════════ */
.ip-tab-content {
  flex: 1; min-height: 0;
  overflow-y: auto;
}
.tab-pane {
  display: flex; flex-direction: column;
}
.tab-empty {
  padding: 26px 17px;
  font-size: 12px;
  color: var(--smax-grey-700);
  text-align: center;
  font-style: italic;
}
.tab-empty ul {
  text-align: left;
  padding: 0 0 0 18px;
  margin: 6px auto 0;
  max-width: 250px;
}
.tab-empty li { margin: 4px 0; }
.parent-card { display: flex; align-items: center; gap: 10px; padding: 10px; border: 1px solid var(--smax-grey-200); border-radius: 8px; background: rgba(0,242,255,0.04); }
.parent-info { flex: 1; min-width: 0; }
.parent-name { font-weight: 600; font-size: 13px; }
.parent-meta { display: flex; gap: 8px; align-items: center; font-size: 11px; flex-wrap: wrap; margin-top: 4px; }
.friends-list { display: flex; flex-direction: column; gap: 10px; }
.friend-card { border: 1px solid var(--smax-grey-200); border-radius: 8px; padding: 10px 12px; background: var(--smax-bg); }
.friend-card-head { display: flex; align-items: center; gap: 10px; margin-bottom: 8px; }
.friend-card-title { flex: 1; min-width: 0; }
.friend-name { font-weight: 600; font-size: 13px; }
.friend-sub { font-size: 11px; color: var(--smax-grey-600); margin-top: 2px; }
.sale-name { font-weight: 500; }
.friend-card-row { display: flex; align-items: center; gap: 6px; font-size: 11.5px; padding: 3px 0; flex-wrap: wrap; }
.friend-card-row .lbl { color: var(--smax-grey-600); }
.friend-card-row .ml-auto { margin-left: auto; }
.friend-card-row.meta-line { padding-top: 6px; border-top: 1px dashed var(--smax-grey-200); margin-top: 4px; color: var(--smax-grey-700); }
.friend-card-row.meta-line strong { color: var(--smax-text); }
.conv-badge {
  font-size: 11px; font-weight: 700;
  padding: 1px 6px; border-radius: 4px;
  margin-left: 4px;
}
.conv-badge--on  { background: rgba(0,200,83,0.15); color: #00897b; }
.conv-badge--off { background: rgba(0,0,0,0.06);    color: #999;    }
.friend-customer-row {
  display: flex; align-items: center; gap: 8px;
  padding: 6px 8px; margin: 4px 0 6px;
  background: var(--smax-grey-50);
  border-radius: 6px;
  border-left: 3px solid var(--smax-primary);
}
.friend-customer-info { flex: 1; min-width: 0; }
.friend-customer-name {
  font-size: 12.5px; font-weight: 600;
  color: var(--smax-text);
  overflow: hidden; text-overflow: ellipsis; white-space: nowrap;
}
.friend-customer-row .uid {
  display: inline-block;
  margin-top: 2px;
}
.friend-card-actions { display: flex; justify-content: flex-end; gap: 6px; padding-top: 8px; border-top: 1px dashed var(--smax-grey-200); margin-top: 6px; }
.btn-sm-danger { padding: 4px 10px; font-size: 11px; border: 1px solid #ffcdd2; color: #c62828; border-radius: 4px; background: rgba(255,82,82,0.05); cursor: pointer; }
.btn-sm-danger:hover { background: rgba(255,82,82,0.15); }
.status-edit { cursor: pointer; padding: 2px 8px; border-radius: 10px; font-size: 11px; }
.status-edit:hover { filter: brightness(1.1); }
.uid { font-family: monospace; font-size: 10.5px; color: var(--smax-grey-700); background: rgba(0,0,0,0.04); padding: 1px 4px; border-radius: 3px; }
.chip-grey { background: rgba(90,100,120,0.10); color: var(--smax-grey-700); padding: 1px 7px; border-radius: 9px; font-size: 10.5px; }
.tab-empty code {
  background: var(--smax-grey-100);
  padding: 0 4px; border-radius: 3px;
  font-size: 10.5px;
}

/* ════════ Inline form ════════ */
.ip-form { padding: 4px 0; border-bottom: 1px solid var(--smax-grey-200); }
.info-expand-toggle {
  width: 100%;
  background: transparent;
  border: none;
  cursor: pointer;
  font-family: inherit;
  font-size: 11px;
  color: var(--smax-primary, #2962ff);
  font-weight: 500;
  padding: 6px 13px;
  text-align: left;
  transition: background 0.12s;
}
.info-expand-toggle:hover { background: var(--smax-primary-soft, #e3f2fd); }
.info-expand-toggle.is-sticky {
  background: linear-gradient(135deg, #FEF3C7, #FDE68A);
  color: #92400E;
  border-color: #FCD34D;
}
.info-expand-toggle .sticky-badge {
  font-size: 11px;
  margin-left: 3px;
}

/* Link Hồ sơ KH tổng hợp — thay thế 3 field email/address/occupation ẩn ở cột 4 */
.info-fullprofile-link {
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 4px;
  width: calc(100% - 24px);
  margin: 6px 12px 4px;
  padding: 8px 10px;
  font-size: 12px;
  font-weight: 600;
  color: #6366F1;
  background: #EEF2FF;
  border: 1px dashed #C7D2FE;
  border-radius: 8px;
  cursor: pointer;
  transition: background 0.15s, border-color 0.15s;
  font-family: inherit;
}
.info-fullprofile-link:hover {
  background: #E0E7FF;
  border-color: #818CF8;
  border-style: solid;
}
.ip-form-row {
  display: grid;
  grid-template-columns: 22px 80px 1fr;
  align-items: center;
  gap: 7px;
  padding: 7px 13px;
  border-bottom: 1px solid var(--smax-grey-100);
}
.ip-form-row.sub {
  grid-template-columns: 22px 80px 1fr;
  padding-left: 32px;
}
.ip-form-row:last-child { border-bottom: none; }
.ip-icon { font-size: 14px; opacity: 0.85; text-align: center; }
.ip-label { font-size: 12px; color: var(--smax-grey-700); }
.ip-form-row input,
.ip-form-row select {
  border: none; outline: none;
  font-size: 13px;
  background: transparent;
  width: 100%; min-width: 0;
  padding: 3px 4px;
  border-radius: 4px;
  font-family: inherit;
  color: var(--smax-text);
}
.ip-form-row input:hover,
.ip-form-row select:hover { background: var(--smax-grey-50); }
.ip-form-row input:focus,
.ip-form-row select:focus { background: var(--smax-primary-soft); }
.phone-cell {
  display: flex; align-items: center; gap: 5px;
  width: 100%;
}
.phone-cell input { flex: 1; }
.show-extra-phones {
  background: var(--smax-grey-100);
  border: 1px solid var(--smax-grey-300);
  border-radius: 9px;
  padding: 1px 7px;
  font-size: 11px;
  color: var(--smax-grey-700);
  cursor: pointer;
  flex-shrink: 0;
}
.show-extra-phones:hover { background: var(--smax-primary-soft); color: var(--smax-primary); }

/* ════════ Section ════════ */
.ip-section {
  padding: 11px 17px;
  border-bottom: 1px solid var(--smax-grey-200);
}
.ip-section:last-child { border-bottom: none; }
.ip-section-title {
  display: flex; align-items: center; gap: 7px;
  font-size: 13px; font-weight: 600;
  color: var(--smax-text);
  margin-bottom: 7px;
}
.ip-section-title .accent {
  width: 3px; height: 14px;
  border-radius: 2px;
  background: var(--smax-grey-300);
}
.scope-tag {
  font-size: 10px; padding: 1px 6px;
  border-radius: 4px;
  font-weight: 500; letter-spacing: 0.3px;
}
.scope-tag.global {
  background: rgba(33,150,243,0.12);
  color: #1565c0;
}
.scope-tag.pernick {
  background: rgba(255,145,0,0.18);
  color: #ef6c00;
}
.refresh-mini {
  margin-left: auto;
  width: 22px; height: 22px;
  border-radius: 50%;
  border: 1px solid var(--smax-grey-300);
  background: var(--smax-bg);
  cursor: pointer;
  font-size: 12px; color: var(--smax-grey-700);
}
.refresh-mini:hover:not(:disabled) { background: var(--smax-grey-50); color: var(--smax-primary); }
.refresh-mini:disabled { opacity: 0.5; cursor: not-allowed; }
.sentiment-reason {
  font-size: 12px;
  color: var(--smax-grey-700);
  margin-top: 7px;
  padding: 7px 9px;
  background: var(--smax-grey-50);
  border-radius: 5px;
  font-style: italic;
}

.tag-list {
  display: flex; flex-wrap: wrap; gap: 4px;
}
.tag-chip {
  background: var(--smax-grey-100);
  color: var(--smax-grey-700);
  padding: 3px 7px;
  border-radius: 7px;
  font-size: 11px;
  display: inline-flex; align-items: center; gap: 4px;
  cursor: default;
}
.tag-chip .x {
  cursor: pointer;
  opacity: 0.55;
  font-weight: 700;
}
.tag-chip .x:hover { opacity: 1; color: var(--smax-error); }
.tag-chip.add {
  background: transparent;
  border: 1px dashed var(--smax-grey-300);
  cursor: pointer;
  color: var(--smax-grey-700);
}
.tag-chip.add:hover { background: var(--smax-grey-50); border-color: var(--smax-primary); color: var(--smax-primary); }
.tag-input {
  border: 1px solid var(--smax-primary);
  outline: none;
  padding: 2px 7px;
  border-radius: 7px;
  font-size: 11px;
  width: 110px;
  font-family: inherit;
}
.tag-suggestions {
  display: flex; flex-wrap: wrap; gap: 4px;
  align-items: center;
  margin-top: 6px;
  padding-top: 6px;
  border-top: 1px dashed var(--smax-grey-200);
}
.suggestion-label {
  font-size: 10.5px;
  color: var(--smax-grey-700);
  text-transform: uppercase;
  letter-spacing: 0.3px;
  font-weight: 600;
}
.tag-chip.suggestion {
  background: transparent;
  border: 1px dashed var(--smax-primary);
  color: var(--smax-primary);
  font-size: 10.5px;
  padding: 2px 7px;
  cursor: pointer;
  border-radius: 7px;
  font-family: inherit;
}
.tag-chip.suggestion:hover {
  background: var(--smax-primary-soft);
}

.metrics-row {
  display: flex; align-items: baseline; gap: 5px;
  font-size: 13px;
}
.metric-num { font-size: 24px; font-weight: 700; color: var(--smax-success); }
.metric-label { color: var(--smax-grey-700); }
.metric-aux  { color: var(--smax-grey-700); font-size: 12px; }

/* ════════ Per-nick state section ════════ */
.kv-list { display: flex; flex-direction: column; gap: 4px; font-size: 12px; line-height: 1.55; }
.kv-row { display: flex; align-items: baseline; gap: 5px; flex-wrap: wrap; }
.kv-row .k { color: var(--smax-grey-700); min-width: 100px; }
.kv-row .v { color: var(--smax-text); font-weight: 500; }
.kv-row .muted { color: var(--smax-grey-300); font-size: 10.5px; font-style: italic; }
.kv-row code {
  font-family: ui-monospace, "Cascadia Code", Menlo, monospace;
  background: var(--smax-grey-100);
  padding: 0 4px; border-radius: 3px;
  font-size: 10px;
}
.status-pill {
  display: inline-flex; align-items: center; gap: 3px;
  padding: 2px 7px; border-radius: 9px;
  font-size: 10px; font-weight: 500;
}
.pill-success { background: rgba(0,200,83,0.12); color: #00897b; }
.pill-warning { background: rgba(255,145,0,0.12); color: #ef6c00; }
.pill-info    { background: rgba(33,150,243,0.12); color: #1565c0; }

.empty-section {
  font-size: 11px; color: var(--smax-grey-700);
  font-style: italic;
  padding: 4px 0;
}

/* ════════ Other nicks list ════════ */
.nick-rows { display: flex; flex-direction: column; gap: 5px; }
.nick-row {
  display: flex; align-items: center; gap: 7px;
  padding: 5px 0;
}
.ni-name { flex: 1; font-size: 12px; color: var(--smax-text); }

/* ════════ Notes section in Tab Hồ Sơ ════════ */
.ip-notes-section {
  margin-top: 10px;
}
</style>
